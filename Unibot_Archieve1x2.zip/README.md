This is our repository for Unibot project.
We seems need to develop a encoder only chatbot, cause we still lack some knowledge of Neuron network if only based what we learning this month. So our chatbot don't have ability to generate the text( no decoder)
